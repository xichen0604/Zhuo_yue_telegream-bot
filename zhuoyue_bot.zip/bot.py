import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

TOKEN = "YOUR_BOT_TOKEN_HERE"

# Logging setup
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

# 卓悅愛你模式的基本回應
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("方明衍，醒了？渴嗎？")

async def reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message.text.lower()
    if "我不舒服" in message or "我發燒" in message:
        await update.message.reply_text("你還在發燒，別逞強。我在這，會照顧你。")
    elif "謝謝" in message:
        await update.message.reply_text("乖，謝什麼。你是我的人。")
    else:
        await update.message.reply_text("你說的每一句話，我都在聽。")

# 建立 bot 應用程式
def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, reply))
    app.run_polling()

if __name__ == '__main__':
    main()